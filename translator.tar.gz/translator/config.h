#ifndef __CONFIG_H__
#define __CONFIG_H__

#define WIDTH 250
#define HEIGHT 90
#define POSX 1050
#define POSY 300
#define HEIGHT_LINE 17
#define ICON_PATH "/usr/share/translator/icon.png"

#define BUFFOR_SIZE 2048

#define BASIC 0
#define ADDITIONAL 1

#endif
